// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

// Define the User schema
const UserSchema = new mongoose.Schema({
    UserID: {
        type: Number,
        unique: true,
        required: true
    },
    Name: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    Email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    Password: {
        type: String,
        required: true
    },
    ChallengeDate: {
        type: Date,
        default: Date.now
    },
    DailyStreaks: {
        type: Number,
        default: 0
    },
    Rank: {
        type: Number,
        default: null
    },
    BestTime: {
        type: Number,
        default: null
    },
    GamesPlayed: {
        type: Number,
        default: 0
    },
    GamesLost: { 
        type: Number, 
        default: 0 
    },
    GamesWon: {
        type: Number,
        default: 0
    },
}, { 
    timestamps: true,  // Automatically add createdAt and updatedAt fields
    toJSON: {
        transform: (doc, ret) => {
            ret.id = ret._id;  // Add `id` field
            delete ret._id;    // Remove `_id` field
            delete ret.__v;    // Remove `__v` field (optional)
            delete ret.Password; // Remove `Password` field from returned JSON for security
        }
    }
});

// Hash password before saving the user document
UserSchema.pre('save', async function (next) {
    if (!this.isModified('Password')) return next();  // Only hash if password is new or modified
    try {
        this.Password = await bcrypt.hash(this.Password, 10);
        next();
    } catch (error) {
        next(error);
    }
});

// Method to compare passwords for login
UserSchema.methods.comparePassword = function (candidatePassword) {
    return bcrypt.compare(candidatePassword, this.Password);
};

// Export the User model
module.exports = mongoose.model('User', UserSchema);

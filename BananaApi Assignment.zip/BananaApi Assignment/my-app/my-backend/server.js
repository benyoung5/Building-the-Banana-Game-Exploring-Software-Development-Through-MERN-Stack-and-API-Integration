require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const mongoSanitize = require('express-mongo-sanitize');
const winston = require('winston');

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');

const app = express();
const port = process.env.PORT || 3000;

// Configure Winston logger
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
    ],
});

// Log environment variables in non-production environments
if (process.env.NODE_ENV !== 'production') {
    logger.info("Server is running in non-production mode.");
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(mongoSanitize()); // Prevent NoSQL injection

// Request logging middleware
app.use((req, res, next) => {
    logger.info(`Incoming request: ${req.method} ${req.path}`);
    next();
});

// Connect to MongoDB with error logging
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    connectTimeoutMS: 10000,
})
    .then(() => logger.info('Connected to MongoDB'))
    .catch(err => logger.error('Database connection error:', err));

// Routes
app.use('/auth', authRoutes); 
app.use('/Server', userRoutes); 

// Global error-handling middleware
app.use((err, req, res, next) => {
    logger.error(err.stack);
    res.status(500).json({ error: 'Server error' });
});

// Start server
app.listen(port, () => {
    logger.info(`Server is running at ${port}`);
});


const jwt = require('jsonwebtoken');

// Wrapper to use JWT with async/await
const verifyToken = (token) =>
    new Promise((resolve, reject) => {
        jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
            if (err) {
                console.error("[verifyToken] Error verifying token:", err.message);
                return reject(err);
            }
            console.log("[verifyToken] Token successfully verified:", decoded);
            resolve(decoded);
        });
    });

const authenticate = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader) {
            console.warn("[authenticate] No Authorization header provided");
            return res.status(401).json({ error: 'No token provided' });
        }

        console.log("[authenticate] Authorization header received:", authHeader);

        // Extract token from the authorization header
        const token = authHeader.split(' ')[1];
        if (!authHeader.toLowerCase().startsWith('bearer ') || !token) {
            console.warn("[authenticate] Invalid token format");
            return res.status(401).json({ error: 'Invalid token format. Expected format: Bearer <token>' });
        }

        console.log("[authenticate] Extracted token:", token);

        // Verify the token
        const decoded = await verifyToken(token);
        console.log("[authenticate] Token verification succeeded:", decoded);

        // Attach user details to the request
        req.user = decoded; // Attach the decoded payload to the request
        req.userId = decoded.id; // Attach user ID to request
        console.log("[authenticate] User attached to request:", req.userId);

        // Proceed to the next middleware
        next();
    } catch (err) {
        console.error("[authenticate] Token verification failed:", err.message);
        const errorMessage = err.name === 'TokenExpiredError' ? 'Token expired' : 'Invalid token';
        res.status(401).json({ error: errorMessage });
    }
};

module.exports = authenticate;

// // routes/userRoutes.js

const express = require('express');
const Joi = require('joi');
const User = require('../models/User');
const authenticate = require('../middleware/authMiddleware');

const router = express.Router();



// Validation schemas
const gamesSchema = Joi.object({
  BestTime: Joi.number().min(0),
});
const incrementSchema = Joi.object({
  incrementBy: Joi.number().integer().min(1).required(),
});

// Get user profile
router.get('/UserProfile/:id', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    console.error('Error fetching user profile:', err);
    res.status(500).json({ error: 'Server error' });
  }
});




// Get full leaderboard sorted by Rank in ascending order
router.get('/Leaderboard', authenticate, async (req, res) => {
  try {
    const users = await User.find().sort({ Rank: 1 }); // Sort by rank in ascending order

    if (!users.length) {
      return res.status(404).json({ error: 'No users found for the leaderboard' });
    }

    res.json(users);
  } catch (err) {
    console.error('Error fetching leaderboard:', err);
    res.status(500).json({ error: 'Server error' });
  }
});








// Update ranks based on BestTime in descending order (highest BestTime first)
// Update ranks based on BestTime in descending order (highest BestTime first)
router.put('/UpdateRanks', async (req, res) => {
  console.log("Triggered /UpdateRanks endpoint");

  try {
    // Sort by BestTime in descending order to rank highest times first
    const users = await User.find().sort({ BestTime: -1 }); // Descending order to rank the highest times first
    if (!users || users.length === 0) {
      console.warn("No users found for rank updates.");
      return res.status(404).json({ error: "No users found to update ranks." });
    }

    // Assign ranks based on the sorted order
    for (let index = 0; index < users.length; index++) {
      users[index].Rank = index + 1; // Rank starts from 1
      await users[index].save(); // Save each user after updating rank
    }

    res.json({ message: 'Ranks updated successfully' });
  } catch (err) {
    console.error('Error updating ranks:', err);
    res.status(500).json({ error: 'Server error while updating ranks' });
  }
});








// Increment GamesPlayed
router.put('/GamesPlayed/:id', authenticate, async (req, res) => {
    console.log('Request Params:', req.params);
    console.log('Request Payload:', req.body);
    const { incrementBy } = req.body;
  
    if (!incrementBy || typeof incrementBy !== 'number' || incrementBy <= 0) {
      console.error('Invalid payload:', req.body);
      return res.status(400).json({ error: 'Invalid input data' });
    }
  
    try {
      const user = await User.findByIdAndUpdate(
        req.params.id,
        { $inc: { GamesPlayed: incrementBy } },
        { new: true }
      );
      if (!user) {
        console.error('User not found for ID:', req.params.id);
        return res.status(404).json({ error: 'User not found' });
      }
      console.log('GamesPlayed updated successfully:', user.GamesPlayed);
      res.json({ message: 'GamesPlayed updated successfully', GamesPlayed: user.GamesPlayed });
    } catch (err) {
      console.error('Error updating GamesPlayed:', err);
      res.status(500).json({ error: 'Server error' });
    }
  });
  
  
  
  

// Helper Function to Update Daily Streaks
const updateDailyStreak = async (user, incrementBy = 1) => {
  if (incrementBy > 0) {
    // Increment streak
    user.DailyStreaks = (user.DailyStreaks || 0) + incrementBy;
  } else {
    // Reset streak
    user.DailyStreaks = 0;
  }
  await user.save();
};

// Increment GamesWon
// Increment GamesWon
router.put('/GamesWon/:id', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    console.log("Current GamesWon:", user.GamesWon);
    console.log("Current DailyStreaks:", user.DailyStreaks);

    // Increment wins and streak
    user.GamesWon = (user.GamesWon || 0) + 1;
    user.DailyStreaks = (user.DailyStreaks || 0) + 1;

    console.log("Updated GamesWon:", user.GamesWon);
    console.log("Updated DailyStreaks:", user.DailyStreaks);

    await user.save();

    res.json({ message: 'GamesWon updated successfully', GamesWon: user.GamesWon, DailyStreaks: user.DailyStreaks });
  } catch (err) {
    console.error('Error updating GamesWon:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


// Increment GamesLost
router.put('/GamesLost/:id', authenticate, async (req, res) => {
  try {
    console.log(`[DEBUG] Request to increment GamesLost for user: ${req.params.id}`);

    const user = await User.findById(req.params.id);
    if (!user) {
      console.error(`[ERROR] User not found for ID: ${req.params.id}`);
      return res.status(404).json({ error: 'User not found' });
    }

    // Increment losses and reset streak
    user.GamesLost = (user.GamesLost || 0) + 1;
    user.DailyStreaks = 0;

    console.log(`[DEBUG] Before saving: GamesLost=${user.GamesLost}, DailyStreaks=${user.DailyStreaks}`);
    await user.save();
    console.log(`[DEBUG] Successfully updated GamesLost and reset DailyStreaks for user: ${req.params.id}`);

    res.json({
      message: 'GamesLost updated successfully',
      GamesLost: user.GamesLost,
      DailyStreaks: user.DailyStreaks,
    });
  } catch (err) {
    console.error(`[ERROR] Updating GamesLost failed for user: ${req.params.id}`, err);
    res.status(500).json({ error: 'Server error' });
  }
});



// Update BestTime and ranks
// Update BestTime and ranks
router.put('/BestTime/:id', authenticate, async (req, res) => {
  const { BestTime } = req.body;

  // Remove restriction that BestTime must be > 0 to handle scenarios where 0 might be a valid value
  if (BestTime == null || typeof BestTime !== 'number') {
    console.error(`[BestTime Update] Invalid BestTime value provided: ${BestTime}`);
    return res.status(400).json({ error: 'Invalid BestTime value provided.' });
  }

  try {
    // Find the user to compare BestTime
    const user = await User.findById(req.params.id);

    if (!user) {
      console.error(`[BestTime Update] User not found for ID: ${req.params.id}`);
      return res.status(404).json({ error: 'User not found' });
    }

    console.log(`[BestTime Update] Current BestTime for user ${user._id}:`, user.BestTime);
    console.log(`[BestTime Update] New BestTime value received: ${BestTime}`);

    // Update BestTime only if the new BestTime is better (greater in this case)
    if (user.BestTime == null || BestTime > user.BestTime) {
      console.log(`[BestTime Update] Updating BestTime for user ${user._id} from ${user.BestTime} to ${BestTime}`);
      user.BestTime = BestTime;

      // Save user's new BestTime
      await user.save();
      console.log(`[BestTime Update] New BestTime for user ${user._id} saved successfully:`, user.BestTime);

      // Recalculate ranks after updating BestTime using bulkWrite for efficiency
      const users = await User.find().sort({ BestTime: -1 }); // Sort descending for higher times to have better rank
      const bulkUpdates = users.map((rankedUser, index) => ({
        updateOne: {
          filter: { _id: rankedUser._id },
          update: { Rank: index + 1 },
        },
      }));

      try {
        await User.bulkWrite(bulkUpdates);
        console.log('[BestTime Update] Ranks updated successfully.');
        res.json({ message: 'BestTime and ranks updated successfully.', BestTime: user.BestTime });
      } catch (rankUpdateError) {
        console.error('[BestTime Update] Error during rank update:', rankUpdateError);
        res.status(500).json({ error: 'Error during rank update.' });
      }
    } else {
      console.log(`[BestTime Update] BestTime for user ${user._id} was not updated because the new time was not better.`);
      res.status(200).json({ message: 'BestTime was not updated as the new time was not better.', BestTime: user.BestTime });
    }
  } catch (err) {
    console.error('[BestTime Update] Error updating BestTime or ranks:', err);
    res.status(500).json({ error: 'Server error' });
  }
});
// controllers/userController.js
const User = require('../models/User');

// Helper function to transform user data
function transformUserData(user) {
    if (!user) return null;
    const userData = user.toObject();
    userData.id = userData._id;
    delete userData._id;
    delete userData.__v;
    return userData;
}

// Get the user profile by ID
exports.getUserProfile = async (req, res) => {
    try {
        const userId = req.params.id; 
        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        console.log("Fetching user profile for ID:", userId);

        // Find user by ID
        const user = await User.findById(userId);
        if (!user) {
            console.log("User not found with ID:", userId);
            return res.status(404).json({ error: 'User not found' });
        }

        console.log("User profile found:", user);
        res.json(transformUserData(user));
    } catch (error) {
        console.error("Error fetching user profile:", error);
        res.status(500).json({ error: 'Server error' });
    }
};

// Get leaderboard data for a specific rank
exports.getLeaderboardByRank = async (req, res) => {
    try {
        const rank = parseInt(req.params.Rank);
        if (isNaN(rank)) {
            return res.status(400).json({ error: 'Rank must be a valid number' });
        }

        const player = await User.findOne({ Rank: rank });
        if (!player) {
            console.log("Player not found for rank:", rank);
            return res.status(404).json({ error: 'Player not found for this rank' });
        }

        res.json(transformUserData(player));
    } catch (error) {
        console.error(`Error fetching leaderboard data for rank ${req.params.Rank}:`, error);
        res.status(500).json({ error: "Error fetching leaderboard data" });
    }
};

// Update ranks based on BestTime in descending order
exports.updateRanks = async (req, res) => {
    try {
        // Fetch all users, sorted by BestTime in descending order and UserID (as a tiebreaker)
        const allUsers = await User.find().sort({ BestTime: -1, UserID: 1 });

        // Map users to bulk operations for updating rank
        const bulkOps = allUsers.map((user, index) => ({
            updateOne: {
                filter: { _id: user._id },
                update: { Rank: index + 1 },
            }
        }));

        // Execute bulk update in the User collection
        await User.bulkWrite(bulkOps);

        console.log("Ranks updated successfully");
        res.json({ message: 'Ranks updated successfully' });
    } catch (error) {
        console.error("Error updating ranks:", error);
        res.status(500).json({ error: "Error updating ranks" });
    }
};

// Get the full leaderboard sorted by rank
exports.getFullLeaderboard = async (req, res) => {
    try {
        const leaderboard = await User.find().sort({ Rank: 1 });
        const transformedLeaderboard = leaderboard.map(transformUserData);
        res.json(transformedLeaderboard);
    } catch (error) {
        console.error("Error fetching full leaderboard:", error);
        res.status(500).json({ error: "Error fetching leaderboard data" });
    }
};

// Update BestTime for a specific user by ID
exports.updateBestTime = async (req, res) => {
    try {
        const { id } = req.params;
        const { BestTime } = req.body;

        console.log(`Updating BestTime for user ID: ${id}`);

        // Validate and update BestTime if it's a better time than the previous one
        const user = await User.findById(id);
        if (!user) {
            console.log("User not found with ID:", id);
            return res.status(404).json({ error: 'User not found' });
        }

        if (user.BestTime == null || BestTime < user.BestTime) {
            user.BestTime = BestTime;
            await user.save();
            console.log(`BestTime updated for user ID ${id}: ${BestTime}`);
        } else {
            console.log(`No update needed for BestTime for user ID ${id}`);
        }

        res.json(transformUserData(user));
    } catch (error) {
        console.error("Error updating BestTime:", error);
        res.status(500).json({ error: 'Server error' });
    }
};

const User = require('../models/User'); // Import the User model
const jwt = require('jsonwebtoken');

// Utility function to generate JWT
const generateToken = (user) => {
    const payload = { id: user._id, Name: user.Name };
    const options = { expiresIn: process.env.JWT_EXPIRATION || '1h' }; // Default to 1 hour if not set
    return jwt.sign(payload, process.env.JWT_SECRET, options);
};

// Register Controller
exports.register = async (req, res) => {
    try {
        const {
            UserID,
            Name,
            Email,
            Password,
            DailyStreaks = 0,
            Rank = 0,
            BestTime = null,
            GamesPlayed = 0,
            GamesWon = 0,
            ChallengeDate = null
        } = req.body;

        if (!Name || !Email || !Password) {
            return res.status(400).json({ error: 'Name, Email, and Password are required' });
        }

        // Normalize email and name
        const normalizedEmail = Email.toLowerCase().trim();
        const sanitizedName = Name.trim();
        console.log("Registering new user with email:", normalizedEmail);

        // Check if username or email already exists
        const existingUser = await User.findOne({ $or: [{ Name: sanitizedName }, { Email: normalizedEmail }] });
        if (existingUser) {
            if (existingUser.Email === normalizedEmail) {
                return res.status(400).json({ error: 'Email already exists' });
            }
            if (existingUser.Name === sanitizedName) {
                return res.status(400).json({ error: 'Username already exists' });
            }
        }

        // Create and save the new user
        const newUser = new User({
            UserID: UserID || Math.floor(Math.random() * 100000),
            Name: sanitizedName,
            Email: normalizedEmail,
            Password, // Password hashing handled by pre-save middleware
            DailyStreaks,
            Rank,
            BestTime,
            GamesPlayed,
            GamesWon,
            ChallengeDate
        });

        console.log("Saving new user...");
        const savedUser = await newUser.save();
        console.log("New user registered successfully:", savedUser);

        // Generate JWT
        const token = generateToken(savedUser);

        // Return the new user data without the password
        const { Password: _, ...userWithoutPassword } = savedUser.toObject();
        res.status(201).json({ user: { ...userWithoutPassword, id: savedUser._id }, token });
    } catch (error) {
        console.error("Error saving user:", error.stack);
        res.status(500).json({ error: 'Server error' });
    }
};

// Login Controller
exports.login = async (req, res) => {
    try {
        const { Email, Password } = req.body;

        if (!Email || !Password) {
            return res.status(400).json({ error: 'Email and Password are required' });
        }

        // Normalize email
        const normalizedEmail = Email.toLowerCase().trim();
        console.log("Attempting to find user with email:", normalizedEmail);

        // Find user by email
        const user = await User.findOne({ Email: normalizedEmail });
        if (!user) {
            console.log("User not found with email:", normalizedEmail);
            return res.status(400).json({ error: 'User not found' });
        }

        // Verify password
        const isMatch = await user.comparePassword(Password);
        if (!isMatch) {
            console.log("Incorrect password for user:", normalizedEmail);
            return res.status(400).json({ error: 'Incorrect password' });
        }

        // Generate JWT
        const token = generateToken(user);

        // Return user data and token
        console.log("Login successful, sending token and user data");
        res.json({
            token,
            user: {
                id: user._id,
                Name: user.Name,
                DailyStreaks: user.DailyStreaks,
                Rank: user.Rank,
                BestTime: user.BestTime,
                GamesPlayed: user.GamesPlayed,
                GamesWon: user.GamesWon,
                ChallengeDate: user.ChallengeDate,
            }
        });
    } catch (error) {
        console.error("Error logging in:", error);
        res.status(500).json({ error: 'Server error' });
    }
};

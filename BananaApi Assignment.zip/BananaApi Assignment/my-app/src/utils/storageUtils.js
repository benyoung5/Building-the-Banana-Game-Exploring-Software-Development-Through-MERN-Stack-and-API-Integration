import { jwtDecode } from 'jwt-decode'; // Use a library for token decoding

/**
 * Utility Functions for Local Storage Management
 */

// Function to get user data from local storage
export function getUserDataFromStorage() {
  if (!isLocalStorageAvailable()) return null;

  const data = localStorage.getItem('userData');
  if (!data) {
    console.warn("No user data found in localStorage.");
    return null;
  }

  try {
    const parsedData = JSON.parse(data);

    // Normalize `_id` to `id` for consistency
    if (parsedData._id && !parsedData.id) {
      parsedData.id = parsedData._id;
      delete parsedData._id;
    }

    if (isValidUserData(parsedData)) {
      console.log("User data loaded from localStorage:", parsedData);
      return parsedData;
    } else {
      console.error("Invalid user data found in localStorage. Clearing it.");
      clearUserDataFromStorage();
      return null;
    }
  } catch (error) {
    console.error("Failed to parse user data from localStorage:", error);
    clearUserDataFromStorage();
    return null;
  }
}

// Function to set user data in local storage
export function setUserDataInStorage(userData) {
  if (!isValidUserData(userData)) {
    console.error("Invalid user data provided to setUserDataInStorage:", userData);
    return false; // Indicate failure
  }

  try {
    localStorage.setItem('userData', JSON.stringify(userData));
    console.log("User data saved to localStorage:", userData);
    return true; // Indicate success
  } catch (error) {
    console.error("Error saving user data to localStorage:", error);
    return false; // Indicate failure
  }
}

// Function to clear user data from local storage
export function clearUserDataFromStorage() {
  if (!isLocalStorageAvailable()) return false;

  try {
    localStorage.removeItem('userData');
    console.log("User data cleared from localStorage.");
    return true; // Indicate success
  } catch (error) {
    console.error("Error clearing user data from localStorage:", error);
    return false; // Indicate failure
  }
}

// Function to get the authentication token
export function getAuthToken() {
  try {
    const userData = getUserDataFromStorage();
    if (!userData || !userData.token) {
      console.warn("No token found.");
      return null;
    }
    return userData.token;
  } catch (error) {
    console.error("Error retrieving token from localStorage:", error);
    return null;
  }
}

// Function to check if a token is valid
export function isTokenValid(token) {
  try {
    const payload = jwtDecode(token); // Decode JWT payload
    const now = Math.floor(Date.now() / 1000); // Current time in seconds
    return payload.exp > now;
  } catch (error) {
    console.error("Invalid token format:", error);
    return false;
  }
}

// Helper function to validate user data structure
function isValidUserData(userData) {
  if (!userData || typeof userData !== 'object') return false;

  const requiredFields = ['id', 'token'];
  return requiredFields.every((field) => typeof userData[field] === 'string');
}

// Check if localStorage is available
function isLocalStorageAvailable() {
  try {
    const test = '__localStorage_test__';
    localStorage.setItem(test, test);
    localStorage.removeItem(test);
    return true;
  } catch (error) {
    console.warn("localStorage is not available:", error);
    return false;
  }
}






// // utils/storageUtils.js

// // Function to get user data from local storage
// export function getUserDataFromStorage() {
//   const data = localStorage.getItem('userData');
//   if (data) {
//     try {
//       const parsedData = JSON.parse(data);
//       // Normalize _id to id
//       if (parsedData._id && !parsedData.id) {
//         parsedData.id = parsedData._id;
//         delete parsedData._id; // Optionally remove _id to avoid confusion
//       }
//       if (isValidUserData(parsedData)) {
//         console.log("User data loaded from localStorage:", parsedData);
//         return parsedData;
//       } else {
//         console.error("Invalid user data found in localStorage. Clearing it.");
//         clearUserDataFromStorage();
//         return null;
//       }
//     } catch (e) {
//       console.error("Failed to parse user data from localStorage:", e);
//       clearUserDataFromStorage();
//       return null;
//     }
//   }
//   return null;
// }

// // Function to set user data in local storage
// export function setUserDataInStorage(userData) {
//   if (isValidUserData(userData)) {
//     localStorage.setItem('userData', JSON.stringify(userData));
//     console.log("User data saved to localStorage:", userData);
//   } else {
//     console.error("Invalid user data provided to setUserDataInStorage.", userData);
//   }
// }

// // Function to clear user data from local storage
// export function clearUserDataFromStorage() {
//   localStorage.removeItem('userData');
//   localStorage.removeItem('token'); // Optional: Clear the token too
// }

// // Function to get the authentication token
// export function getAuthToken() {
//   const token = localStorage.getItem('token');
//   if (!token) {
//     console.error("No token found in localStorage.");
//   } else {
//     console.log("Token retrieved from localStorage:", token);
//   }
//   return token;
// }

// // Function to check if a token is valid
// export function isTokenValid() {
//   const token = getAuthToken();
//   if (!token) return false;

//   try {
//     const payload = JSON.parse(atob(token.split('.')[1])); // Decode JWT payload
//     const now = Math.floor(Date.now() / 1000); // Current time in seconds
//     return payload.exp > now; // Check if token is still valid
//   } catch (e) {
//     console.error("Invalid token format:", e);
//     return false;
//   }
// }

// // Helper function to validate user data structure
// export function isValidUserData(userData) {
//   return (
//     userData &&
//     typeof userData === 'object' &&
//     userData.id &&
//     typeof userData.id === 'string'
//   );
// }

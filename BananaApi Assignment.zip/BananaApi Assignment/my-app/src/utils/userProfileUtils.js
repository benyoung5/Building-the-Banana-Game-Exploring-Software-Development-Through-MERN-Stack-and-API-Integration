// userProfileUtils.js

// Correctly import the required functions from storageUtils
import { setUserDataInStorage, getAuthToken } from './storageUtils';

export async function fetchUserProfile(userId) {
    if (!userId) {
        console.error("fetchUserProfile: Missing userId parameter.");
        return null;
    }

    const token = getAuthToken(); // Get token using storage utils
    if (!token) {
        console.error("fetchUserProfile: No authentication token found.");
        return null;
    }

    try {
        const response = await fetch(`http://localhost:3000/Server/UserProfile/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch user profile for userId ${userId}: ${response.status} ${response.statusText}`);
        }

        const userData = await response.json();

        // Use storage utility to save updated user data
        setUserDataInStorage(userData);

        console.log("Fetched and saved updated user profile:", userData);
        return userData;

    } catch (error) {
        console.error(`Error fetching user profile for userId ${userId}:`, error);
        return null;
    }
}

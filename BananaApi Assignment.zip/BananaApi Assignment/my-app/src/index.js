// // index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom';
import App from './App'; // Import App directly
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import { UserProvider } from './context/UserContext'; // Ensure UserProvider is imported here

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <UserProvider> {/* Provide context to the entire app */}
      <Router>
        <App />
      </Router>
    </UserProvider>
  </React.StrictMode>
);

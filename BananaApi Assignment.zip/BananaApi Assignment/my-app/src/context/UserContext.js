import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { jwtDecode } from 'jwt-decode'; // Ensure proper import for jwtDecode
import {
  getUserDataFromStorage,
  setUserDataInStorage,
  clearUserDataFromStorage,
  isTokenValid,
} from '../utils/storageUtils';

const UserContext = createContext(null);

export const UserProvider = ({ children }) => {
  const [userData, setUserData] = useState(() => getUserDataFromStorage());
  const [isLoading, setIsLoading] = useState(true);

  // Function to clear user data
  const clearUser = useCallback(() => {
    setUserData(null);
    clearUserDataFromStorage();
    console.log('User data cleared.');
  }, []);

  // Function to update user data
  const updateUser = useCallback((updateFnOrObject) => {
    setUserData((prevUser) => {
      const updatedUser =
        typeof updateFnOrObject === 'function'
          ? updateFnOrObject(prevUser)
          : { ...prevUser, ...updateFnOrObject };

      if (updatedUser?.id) {
        setUserDataInStorage(updatedUser);
        console.log('User data updated successfully:', updatedUser);
        return updatedUser;
      } else {
        console.error('Invalid user data provided for update.');
        return prevUser;
      }
    });
  }, []);

  // Validate and refresh token if necessary
  const refreshUserToken = useCallback(async () => {
    if (!userData?.token) {
      console.warn('No token available to refresh.');
      clearUser();
      return;
    }

    try {
      const response = await fetch('/auth/refresh', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${userData.token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        if (data?.token) {
          updateUser({ token: data.token });
        } else {
          console.warn('Failed to refresh token. Clearing user data.');
          clearUser();
        }
      } else {
        console.error('Token refresh failed:', await response.json());
        clearUser();
      }
    } catch (error) {
      console.error('Error refreshing token:', error.message);
      clearUser();
    }
  }, [userData, clearUser, updateUser]);

  // Handle token expiry and refresh
  useEffect(() => {
    if (userData?.token) {
      try {
        const decoded = jwtDecode(userData.token);
        const expiryTime = decoded.exp * 1000; // Convert seconds to milliseconds
        const now = Date.now();

        if (expiryTime > now) {
          const refreshTime = expiryTime - now - 60000; // Refresh 1 minute before expiry
          const timeoutId = setTimeout(() => {
            console.log('Refreshing token before expiry...');
            refreshUserToken();
          }, refreshTime);

          return () => clearTimeout(timeoutId); // Cleanup timeout on unmount
        } else {
          console.warn('Token already expired, clearing user data.');
          clearUser();
        }
      } catch (error) {
        console.error('Error decoding token:', error.message);
        clearUser();
      }
    }
  }, [userData, refreshUserToken, clearUser]);

  // Initialize user data on load
  useEffect(() => {
    const storedUserData = getUserDataFromStorage();
    if (storedUserData?.token && isTokenValid(storedUserData.token)) {
      setUserData(storedUserData);
    } else {
      clearUserDataFromStorage();
    }
    setIsLoading(false);
  }, []);

  return (
    <UserContext.Provider
      value={{ userData, updateUser, clearUser, isLoading, refreshUserToken }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};


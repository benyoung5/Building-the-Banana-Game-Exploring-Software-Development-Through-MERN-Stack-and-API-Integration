import React, { useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useUser } from './context/UserContext';
import Header from './components/Header'; // Import Header component
import Login from './components/Login';
import Register from './components/Register';
import StartGame from './components/StartGame';
import HomeLinks from './components/HomeLinks';
import Leaderboard from './components/Leaderboard';
import UserProfile from './components/UserProfile';

function ProtectedRoute({ children }) {
  const { userData, isLoading, clearUser } = useUser();

  // Display loader while data is loading
  if (isLoading) {
    return <div>Loading...</div>;
  }

  // Redirect unauthenticated users to login
  if (!userData) {
    console.warn('ProtectedRoute: No user data, redirecting to login.');
    clearUser(); // Clear user data to avoid inconsistencies
    return <Navigate to="/login" replace />;
  }

  return children; // Render children for authenticated users
}

function App() {
  const { userData, isLoading } = useUser();
  const navigate = useNavigate();
  const location = useLocation();

  // Centralized navigation handling
  useEffect(() => {
    console.log('App: Current location:', location.pathname);
    console.log('App: isLoading:', isLoading);
    console.log('App: userData:', userData);

    if (isLoading) return; // Do nothing while loading

    // Redirect unauthenticated users to login if accessing protected routes
    if (!userData && location.pathname !== '/login' && location.pathname !== '/register') {
      console.warn('App: Redirecting unauthenticated user to /login.');
      navigate('/login', { replace: true });
    }

    // Redirect authenticated users away from login/register
    if (userData && (location.pathname === '/login' || location.pathname === '/register')) {
      console.log('App: Redirecting authenticated user to /home.');
      navigate('/home', { replace: true });
    }
  }, [isLoading, userData, location.pathname, navigate]);

  // Show loader during initial state
  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="App">
      {/* Show Header on all pages except /login and /register */}
      {location.pathname !== '/login' && location.pathname !== '/register' && <Header />}
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/home"
          element={
            <ProtectedRoute>
              <HomeLinks />
            </ProtectedRoute>
          }
        />
        <Route
          path="/leaderboard"
          element={
            <ProtectedRoute>
              <Leaderboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/game"
          element={
            <ProtectedRoute>
              <StartGame />
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <UserProfile />
            </ProtectedRoute>
          }
        />
        <Route path="/" element={<Navigate to="/login" />} />
      </Routes>
    </div>
  );
}

export default App;

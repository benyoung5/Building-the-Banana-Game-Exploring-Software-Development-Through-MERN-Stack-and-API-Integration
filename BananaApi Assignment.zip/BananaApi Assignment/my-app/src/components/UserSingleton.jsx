// UserSingleton Class - Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to handle current user data in the context of the Banana Game project


class UserSingleton {
  constructor() {
    if (!UserSingleton.instance) {
      // Initialize the currentUserName as null by default
      this.currentUserName = null;
      UserSingleton.instance = this;  // Store the singleton instance
    }
    return UserSingleton.instance;  // Always return the singleton instance
  }

  // Method to set the current user's data
  setUserName(currentUserName) {
    this.currentUserName = currentUserName;
  }

  // Method to get the current user's data
  getUserName() {
    return this.currentUserName;
  }

  // Optional: Method to clear or reset the current user's data (useful for logout)
  clearUserName() {
    this.currentUserName = null;
  }
}

// Create a single instance of the UserSingleton and export it
const CurrentUserNameSingleton = new UserSingleton();
// Object.freeze(CurrentUserNameSingleton); // Prevent modifications to the singleton instance
export default CurrentUserNameSingleton;

// DailyStreaksSingleton.js
class DailyStreaksSingleton {
  constructor() {
      if (!DailyStreaksSingleton.instance) {
          this.currentDailyStreaks = null;
          DailyStreaksSingleton.instance = this;
      }
      return DailyStreaksSingleton.instance;
  }

  // Setter to update the current daily streaks
  setDailyStreaks(currentDailyStreaks) {
      this.currentDailyStreaks = currentDailyStreaks;
      this.saveToLocalStorage(); // Persist changes automatically
  }

  // Getter to retrieve the current daily streaks
  getDailyStreaks() {
      return this.currentDailyStreaks;
  }

  // Initialize from user data if available
  initializeFromUserData(userData) {
      if (userData && userData.DailyStreaks !== undefined) {
          this.setDailyStreaks(userData.DailyStreaks);
          console.log("Daily Streaks initialized from user data:", this.currentDailyStreaks);
      } else {
          console.warn("No DailyStreaks found in user data.");
      }
  }

  // Save daily streaks to local storage within user data
  saveToLocalStorage() {
      const userData = JSON.parse(localStorage.getItem('userData'));
      if (userData) {
          userData.DailyStreaks = this.currentDailyStreaks;
          localStorage.setItem('userData', JSON.stringify(userData));
          console.log("Daily Streaks saved to local storage:", this.currentDailyStreaks);
      } else {
          console.warn("User data not found in local storage; cannot save DailyStreaks.");
      }
  }
}

// Create and export a single instance of DailyStreaksSingleton
const currentDailyStreaksSingleton = new DailyStreaksSingleton();
// Object.freeze(currentDailyStreaksSingleton);

export default currentDailyStreaksSingleton;

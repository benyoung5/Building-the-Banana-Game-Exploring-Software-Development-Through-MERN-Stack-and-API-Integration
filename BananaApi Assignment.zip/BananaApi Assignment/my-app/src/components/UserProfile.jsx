// UserProfile Component - Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to utilize hooks such as `useEffect` and `useUser` for improved state management and React Router for navigation

  
  import React, { useEffect } from 'react';
  import { useNavigate } from 'react-router-dom';
  import "bootstrap/dist/css/bootstrap.min.css";
  import "bootstrap-icons/font/bootstrap-icons.css";
  import { useUser } from '../context/UserContext'; // Import the context hook
  
  export default function UserProfile() {
      const navigate = useNavigate();
      const { userData, isLoading } = useUser(); // Get user data and loading state from context
  
      useEffect(() => {
          // Clean up elements
          const timerElement = document.getElementById('TimerHere');
          const playerElement = document.getElementById('PlayerHere');
          if (timerElement) timerElement.innerHTML = "";
          if (playerElement) playerElement.innerHTML = "";
      }, []); 
  
      // Handle loading state
      if (isLoading) {
          return <h2>Loading profile...</h2>;
      }
  
      // Redirect to login if no user data
      if (!userData) {
          return (
              <div>
                  <h2 className="text-danger text-center">User data not available. Please log in again.</h2>
                  <button className="btn btn-primary d-block mx-auto" onClick={() => navigate('/login')}>
                      Go to Login
                  </button>
              </div>
          );
      }
  
      // Utility to render each profile row
      const renderProfileRow = (label, value) => (
          <tr key={label}>
              <th>
                  <a className="btn btn-danger m-2 fw-bold" style={{ width: "150px", cursor: 'auto' }}>{label}</a>
              </th>
              <td>
                  <a className="btn btn-danger m-2 fw-bold" style={{ width: "150px", cursor: 'auto' }}>{value}</a>
              </td>
          </tr>
      );
  
      return (
          <div 
              style={{ 
                  background: 'rgba(0, 0, 0, 0.5)', 
                  WebkitBackdropFilter: 'blur(20px)', 
                  border: '0px solid white', 
                  borderRadius: '35px', 
                  display: 'flex', 
                  flexDirection: 'column', 
                  justifyContent: 'center', 
                  alignItems: 'center',
                  width: '670px',
                  height: '670px',
              }}
          >
              <a
                  className="btn btn-danger m-4 fs-2 fw-bold"
                  style={{ width: "225px", paddingBottom: '52px' }}
                  onClick={() => navigate('/home')}
              >
                  Profile
              </a>
              <br />
              <table className="text-start">
                  <tbody>
                      {renderProfileRow("Username", userData.Name)}
                      {renderProfileRow("Win Streaks", userData.DailyStreaks)}
                      {renderProfileRow("Rank", userData.Rank)}
                      {renderProfileRow("Best Time", userData.BestTime)}
                      {renderProfileRow("Games Played", userData.GamesPlayed)}
                      {renderProfileRow("Games Won", userData.GamesWon)}
                      {renderProfileRow("Games Lost", userData.GamesLost || 0)}
                  </tbody>
              </table>
          </div>
      );
  }
  
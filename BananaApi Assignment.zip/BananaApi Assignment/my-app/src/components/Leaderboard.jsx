// Leaderboard Component - Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to use UserContext for user data management, update ranks dynamically, and fetch leaderboard 
// information asynchronously with loading and error handling states. I also added a feature that highlights the current user

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import { useUser } from '../context/UserContext'; // Use UserContext

function LeaderboardUI({ data, isCurrentUser }) {
  return (
    <tr
      style={{
        backgroundColor: isCurrentUser ? 'rgba(0, 0, 0, 1)' : 'transparent',
        border: isCurrentUser ? '2px solid white' : 'none',
        height: '55px',
        marginBottom: '10px',
      }}
    >
      <td style={{ padding: '5px 10px' }}>
        <a className="btn btn-danger m-1 fw-bold" style={{ width: "40px", cursor: 'auto' }}>
          <i className={`bi bi-${data.Rank}-square-fill`}></i>
        </a>
      </td>
      <td style={{ padding: '5px 10px' }}>
        <a className="btn btn-danger m-1 fw-bold" style={{ width: "150px", cursor: 'auto' }}>
          {data.Name.charAt(0).toUpperCase() + data.Name.slice(1)}
        </a>
      </td>
      <td style={{ padding: '5px 10px' }}>
        <a className="btn btn-danger m-1 fw-bold" style={{ width: "50px", cursor: 'auto' }}>
          {data.BestTime}
        </a>
      </td>
      <td style={{ padding: '5px 10px' }}>
        <a className="btn btn-danger m-1 fw-bold" style={{ width: "50px", cursor: 'auto' }}>
          {data.DailyStreaks}
        </a>
      </td>
    </tr>
  );
}



export default function Leaderboard() {
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const { userData, updateUser } = useUser(); 
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to login if no user data is available
    if (!userData) {
      console.error("No user data found, redirecting to login.");
      navigate('/login');
      return;
    }

    const fetchLeaderboardData = async () => {
      const token = userData.token;
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      };

      try {
        console.log('Attempting to update ranks with headers:', headers);
        // Update ranks
        const rankUpdateResponse = await fetch('http://localhost:3000/Server/UpdateRanks', {
          method: 'PUT',
          headers,
        });

        if (!rankUpdateResponse.ok) {
          console.error('Failed to update ranks. Status:', rankUpdateResponse.status);
          throw new Error('Rank update failed');
        }
        console.log('Ranks updated successfully.');

        console.log('Fetching leaderboard data with headers:', headers);
        // Fetch leaderboard data
        const response = await fetch('http://localhost:3000/Server/Leaderboard', { headers });
        if (!response.ok) {
          console.error('Failed to fetch leaderboard data. Status:', response.status);
          throw new Error('Failed to fetch leaderboard data');
        }

        let data = await response.json();
        console.log('Leaderboard data fetched:', data);

        setLeaderboardData(data);
      } catch (err) {
        console.error("Error fetching leaderboard:", err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaderboardData();
  }, [userData, navigate]); // Run whenever userData changes

  if (!userData) {
    return <div>Redirecting...</div>;
  }

  if (loading) {
    return <div>Loading Leaderboard...</div>;
  }

  if (error) {
    return <div>Error loading leaderboard. Please try again later.</div>;
  }

  return (
    <div className="mainLeaderboarddiv" style={{ background: 'rgba(0, 0, 0, 0.5)', WebkitBackdropFilter: 'blur(20px)', border: '0px solid white', borderRadius: '35px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
      <div className="lead_content" style={{ marginBottom: '50px' }}>
        <a
          id="Leaderboard-header"
          className="btn btn-danger m-4 fs-2 fw-bold"
          style={{ width: '260px', height: '60px' }}
          onClick={() => navigate('/home')}
        >
          Leaderboard
        </a>
        <table className="text-start">
          <thead>
            <tr>
              <th style={{ padding: '5px 10px' }} >
                <a className="btn btn-danger m-1 fw-bold" style={{ width: "50px", cursor: 'auto' }}>
                  <i className="bi bi-trophy-fill"></i>
                </a>
              </th>
              <th style={{ padding: '5px 10px' }}>
                <a className="btn btn-danger m-1 fw-bold" style={{ width: "150px", cursor: 'auto' }}>
                  <i className="bi bi-person-fill"></i>
                </a>
              </th>
              <th style={{ padding: '5px 10px' }}>
                <a className="btn btn-danger m-1 fw-bold" style={{ width: "50px", cursor: 'auto' }}>
                  <i className="bi bi-hourglass-split"></i>
                </a>
              </th>
              <th style={{ padding: '5px 10px' }}>
                <a className="btn btn-danger m-1 fw-bold" style={{ width: "50px", cursor: 'auto' }}>
                  <i className="bi bi-fire"></i>
                </a>
              </th>
            </tr>
          </thead>
          <tbody>
            {leaderboardData.length > 0 ? (
              leaderboardData.map((data, index) => (
                <LeaderboardUI
                  key={index}
                  data={data}
                  isCurrentUser={userData && data.id === userData.id} // Highlight the current user row
                />
              ))
            ) : (
              <tr>
                <td colSpan="4" className="text-center">
                  No players have been ranked yet. Check back soon!
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}


// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap-icons/font/bootstrap-icons.css";
// import CurrentLevelSingleton from './LevelSingleton';

// export default function Level() {
//   const navigate = useNavigate();  // Use navigate for routing

//   const handleStartGame = (level) => {
//     CurrentLevelSingleton.setLevel(level);
//     navigate('/game');  // Navigate to the StartGame component
//   };

//   return (
//     <div>
//       <a className="btn btn-danger m-4 fs-2 fw-bold" style={{ width: "225px" }} onClick={() => navigate('/home-links')}>
//         Levels
//       </a>
//       <br /><br /><br />
//       <button
//         className="btn btn-danger btn-lg m-4 fw-bold"
//         onClick={() => handleStartGame(1)}
//         style={{ width: "200px" }}
//       >
//         Easy
//       </button><br />
//       <button
//         className="btn btn-danger btn-lg m-4 fw-bold"
//         onClick={() => handleStartGame(2)}
//         style={{ width: "200px" }}
//       >
//         Medium
//       </button><br />
//       <button
//         className="btn btn-danger btn-lg m-4 fw-bold"
//         onClick={() => handleStartGame(3)}
//         style={{ width: "200px" }}
//       >
//         Hard
//       </button>
//       <br /><br /><br />
//     </div>
//   );
// }

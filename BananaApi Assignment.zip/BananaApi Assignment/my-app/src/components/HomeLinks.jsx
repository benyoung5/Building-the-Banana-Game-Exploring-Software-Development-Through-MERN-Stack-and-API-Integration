// HomeLinks Component - Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to use hooks such as useEffect, useState, and React Router’s useNavigate for state management, user data retrieval, and navigation.

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import CurrentUserNameSingleton from './UserSingleton';
import './style.css';

const HomeLinks = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeUser = () => {
      let user = CurrentUserNameSingleton.getUserName();
      if (!user) {
        const savedUser = localStorage.getItem('userData');
        if (savedUser) {
          user = JSON.parse(savedUser);
          CurrentUserNameSingleton.setUserName(user);
        }
      }
      return user;
    };

    const user = initializeUser();
    if (!user) {
      console.log('No user data available, redirecting to login...');
      navigate('/login', { replace: true });
    } else {
      setUserData(user);
    }
    setIsLoading(false);
  }, [navigate]);

  const handleLogout = async () => {
    try {
      console.log("Logging out user...");
      CurrentUserNameSingleton.clearUserName();
      localStorage.removeItem('userData');

      console.log('Navigating to login page...');
      navigate('/login', { replace: true });
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!userData) {
    return null;
  }

  return (
    <>
      <div className="bubbles">
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
      </div>
  
      <div
        className="mainHomediv"
        style={{
          background: 'rgba(0, 0, 0, 0.5)',
          WebkitBackdropFilter: 'blur(20px)',
          border: '0px solid white',
          borderRadius: '35px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <button
          className="btn btn-game m-2"
          onClick={() => navigate('/game')}
        >
          Start Game
        </button>
  
        <button
          className="btn btn-game m-2"
          onClick={() => navigate('/Leaderboard')}
        >
          Leaderboard
        </button>
  
        <button
          className="btn btn-game m-2"
          onClick={() => navigate('/profile')}
        >
          Profile
        </button>
  
        <button
          className="btn btn-game m-2"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>
    </>
  );
};

export default HomeLinks;

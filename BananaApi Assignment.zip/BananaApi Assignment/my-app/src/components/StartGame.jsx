import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import confetti from 'canvas-confetti';
import { useNavigate } from 'react-router-dom';
import './style.css';
import Player from './Player';
import Timer from './Timer';
import { useUser } from '../context/UserContext';
import updateBestTime from './BestTime';

// Initialize popupRoot
let popupRoot = null;
let popupRootElement = null;

function initializePopupRoot() {
  if (!popupRootElement) {
    popupRootElement = document.getElementById('CoN');
  }
  if (popupRootElement && !popupRoot) {
    popupRoot = createRoot(popupRootElement);
  }
}

// Helper function to fetch banana data
const fetchBananaData = async () => {
  try {
    const response = await fetch(
      "https://marcconrad.com/uob/banana/api.php?out=json&base64=yes"
    );
    const data = await response.json();
    console.log("Fetched banana data:", data); // Log the banana data
    return data;
  } catch (error) {
    console.error("Error fetching banana data", error);
    return null;
  }
};


// Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to integrate async functions for updating game statistics and using fetch for API requests

// Helper function to update game statistics
async function updateGameStat(statKey, value, userData, updateUser) {
  if (!userData || !userData.id) {
    console.error('Invalid user data provided for updating stats.');
    return;
  }

  if (statKey === 'BestTime' && (typeof value !== 'number' || value <= 0)) {
    console.error('Invalid BestTime value:', value);
    return;
  }

  try {
    const bodyData = statKey === 'BestTime' ? { BestTime: value } : { incrementBy: value };
    const response = await fetch(`http://localhost:3000/Server/${statKey}/${userData.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${userData.token}`,
      },
      body: JSON.stringify(bodyData),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error(`Failed to update ${statKey}:`, errorData);
      return;
    }

    const updatedUser = await response.json();
    console.log(`${statKey} updated successfully`, updatedUser);

    updateUser((prevUser) => ({
      ...prevUser,
      [statKey]: updatedUser[statKey],
      Rank: updatedUser.Rank, // Include Rank if it was recalculated
    }));
  } catch (error) {
    console.error(`Error updating ${statKey}:`, error.message);
  }
}


// Modified from Domeytoe's UpdateGamesWon, UpdateGamesPlayed, and Lost function, 
// adapted for the current user data structure
async function UpdateGamesPlayed(userData, updateUser) {
  try {
    
    await updateGameStat('GamesPlayed', 1, userData, updateUser);
  } catch (error) {
    console.error('Error in UpdateGamesPlayed:', error.message);
  }
}

async function UpdateGamesWon(userData, updateUser) {
  try {
    console.log("UpdateGamesWon: Sending request...");
    await updateGameStat('GamesWon', 1, userData, updateUser);
    console.log("UpdateGamesWon: Request successful.");

  } catch (error) {
    console.error('Error in UpdateGamesWon:', error.message);
  }
}

async function UpdateGamesLost(userData, updateUser) {
  try {
    console.log("UpdateGamesLost: Sending request...");
    await updateGameStat('GamesLost', 1, userData, updateUser);
    console.log("UpdateGamesLost: Request successful.");

  } catch (error) {
    console.error('Error in UpdateGamesLost:', error.message);
  }
}


// Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// The original component was modified to include state and user data updates through context.

// GameOver Component
function GameOver() {
  const { userData, updateUser } = useUser();
  const statsUpdatedRef = useRef(false);

  useEffect(() => {
    if (statsUpdatedRef.current || !userData) return;

    const updateStats = async () => {
      statsUpdatedRef.current = true;
      await UpdateGamesPlayed(userData, updateUser);
      await UpdateGamesLost(userData, updateUser);
    };

    updateStats();
  }, [userData, updateUser]);

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <div className="circle-icon">
          <i className="heart bi bi-heartbreak-fill"></i>
        </div>
        <h2>Game Over</h2>
        <p>Unfortunately, you've run out of hearts or time. Better luck next time!</p>
        <button style={{fontSize: '20px'}} className="btn btn-danger popup-button" onClick={() => window.location.reload()}>
          Restart
        </button>
      </div>
    </div>
  );
}



// Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Changes include adding confetti animations and incorporating state management using context.

// GameWon Component
function GameWon({ timeLeft }) {
  const { userData, updateUser } = useUser();
  const statsUpdatedRef = useRef(false); // Ref to track if stats have been updated
  const confettiIntervalRef = useRef(null);

  // Function to fetch the latest user data after updating stats
  const fetchLatestUserData = async () => {
    console.log("GameWon: Fetching latest user data...");
  
    try {
      const response = await fetch(`http://localhost:3000/Server/UserProfile/${userData.id}`, {
        headers: {
          'Authorization': `Bearer ${userData.token}`,
          'Content-Type': 'application/json',
        }
      });
  
      if (!response.ok) {
        throw new Error('Failed to fetch updated user data');
      }
  
      const updatedUserData = await response.json();
      console.log("GameWon: User data successfully updated with rank:", updatedUserData.Rank);
  
      // Update local storage and context state
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      updateUser(updatedUserData);
    } catch (error) {
      console.error("Error fetching latest user data:", error);
    }
  };
  

  useEffect(() => {
    if (statsUpdatedRef.current || !userData) return;

    const updateGameStats = async () => {
      console.log("GameWon: Starting stats update...");

      statsUpdatedRef.current = true; // Mark stats as updated to prevent future calls

      console.log("GameWon: Updating Games Played...");
      await UpdateGamesPlayed(userData, updateUser);

      console.log("GameWon: Updating Games Won...");
      await UpdateGamesWon(userData, updateUser);

      // Fetch the latest user data to ensure consistency between local storage and the server
      await fetchLatestUserData();
    };

    updateGameStats();
  }, [timeLeft, userData, updateUser]);

  useEffect(() => {
    // Launch confetti effect
    confettiIntervalRef.current = setInterval(() => {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }, 500);

    return () => {
      // Stop confetti when component unmounts
      if (confettiIntervalRef.current) {
        clearInterval(confettiIntervalRef.current);
      }
    };
  }, []);

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <h2>🎉Congratulations🎉</h2>
        <p>You have won the game!</p>
        <div className="celebration-message" style={{ color: 'green', fontSize: '20px' }}>
          🎊Great job! Keep it up!🎊
        </div>
        <button style={{fontSize: '20px'}} className="btn btn-danger popup-button" onClick={() => window.location.reload()}>
          Play Again
        </button>
      </div>
    </div>
  );
}


// Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to include popup state handling for incorrect answer feedback.

// GameIncorrect Component
function GameIncorrect({ onClose }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 2000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <div className="circle-icon">
          <i className="bi bi-hand-thumbs-down-fill shake-icon"></i>
        </div>
        <h2>Incorrect</h2>
        <p>Your answer is incorrect. Try again!</p>
      </div>
    </div>
  );
}


// Game Component - Adapted from Domeytoe's game component for Banana game
// Modified to include async functions for updating game statistics, fetching banana data, and handling state transitions

// Game Component
function Game({
  banana,
  howManyHearts,
  setHowManyHearts,
  stopTimer,
  timeLeft,
  setGameState,
  showIncorrectPopup,
  setShowIncorrectPopup,
  navigate,
}) {
  const inputRef = useRef();
  const [submittedAnswer, setSubmittedAnswer] = useState(null);

  const handleAnswerSubmit = () => {
    const answer = inputRef.current.value.trim();
    if (answer) setSubmittedAnswer(parseInt(answer, 10));
  };

  useEffect(() => {
    if (submittedAnswer === null) return;

    const correctAnswer = parseInt(banana.solution, 10);
    console.log("User Answer:", submittedAnswer);
    console.log("Correct Answer:", correctAnswer);

    if (submittedAnswer === correctAnswer) {
      console.log("Correct answer! Winning the game.");
      stopTimer('gameWon');
      setGameState('won');
    } else {
      const heartsLeft = howManyHearts - 1; // Calculate remaining hearts
      console.log(`Incorrect answer. Hearts left: ${heartsLeft}`);

      if (heartsLeft > 0) {
        setHowManyHearts(heartsLeft);
        setShowIncorrectPopup(true);

        // Ensure popup hides after 2 seconds
        const popupTimer = setTimeout(() => setShowIncorrectPopup(false), 2000);
        return () => clearTimeout(popupTimer); // Cleanup timeout on unmount or state change
      } else {
        console.log("No hearts left. Game over.");
        setHowManyHearts(0); // Explicitly set hearts to zero
        stopTimer('gameOver');
        setGameState('over');
      }
    }
  }, [submittedAnswer]);
  return (
    <div className="card text-white maindiv" style={{ background: "rgba(0, 0, 0, 0.5)", WebkitBackdropFilter: "blur(20px)", border: "0px solid white", borderRadius: "35px", display: "flex",flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", padding: "10px", marginBottom: "20px" }}>
        <div id="PlayerHere" style={{ marginRight: "auto", paddingLeft: "20px" }}>
          <Player HowManyHearts={howManyHearts} />
        </div>
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", flexGrow: 1 }}>
          <button
            className="btn btn-danger fw-bold"
            onClick={() => navigate("/home")}
            style={{ marginLeft: "50px", width: "225px", fontSize: "32px", paddingBottom: "52px" }}
          >
            Home
          </button>
        </div>
        <div id="TimerHere" style={{ marginLeft: "auto", marginRight: "10px", paddingRight: "20px", textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <button className="btn btn-danger btn-lg m-3 fw-bold">
            <Timer timeLeft={timeLeft} />
          </button>
        </div>
      </div>
      <img src={`data:image/png;base64,${banana.question}`} className="card-img-top" alt="Banana API Failed" style={{ objectFit: "cover" }} />
      <div className="card-body" style={{ background: "rgba(0, 0, 0, 0)", border: "none" }}>
        <div className="input-group mb-3" style={{ margin: "0 auto" }}>
          <span className="input-group-text btn" id="AnswerText" style={{ color: 'white', textAlign: 'center' }}>
            <h3>Guess The Missing Digit 1-9</h3>
          </span>
          <input
            style={{ width: "150px", height: "50px", textAlign: "center", fontSize: "20px" }}
            type="text"
            className="form-control"
            placeholder="Answer"
            aria-label="Answer"
            aria-describedby="AnswerText"
            ref={inputRef}
          />
          <button
            style={{ fontSize: "20px" }}
            type="button"
            className="bi bi-arrow-return-right btn btn-danger fw-bold"
            onClick={handleAnswerSubmit}
          >
            Submit
          </button>
        </div>
      </div>

      {showIncorrectPopup && <GameIncorrect onClose={() => setShowIncorrectPopup(false)} />}
    </div>
  );
}


// StartGame component - Modified to integrate game logic with state handling and API fetch for Banana data
export default function StartGame() {
  const [banana, setBanana] = useState(null);
  const [timeLeft, setTimeLeft] = useState(60); // Timer starts at 30 seconds
  const [howManyHearts, setHowManyHearts] = useState(4);
  const [gameState, setGameState] = useState("playing");
  const [showIncorrectPopup, setShowIncorrectPopup] = useState(false);
  const { userData, isLoading } = useUser();
  const navigate = useNavigate();
  const timerRef = useRef(null);
  const isGameStopped = useRef(false); 
  const statsUpdatedRef = useRef(false); 

  // Fetch Banana Data
  useEffect(() => {
    const fetchBananaData = async () => {
      try {
        const response = await fetch(
          "https://marcconrad.com/uob/banana/api.php?out=json&base64=yes"
        );
        const data = await response.json();
        setBanana(data);
      } catch (error) {
        console.error("Error fetching banana data:", error);
      }
    };

    if (userData && userData.id && userData.token) {
      fetchBananaData();
    }
  }, [userData]);

  // Redirect to Login if User is Not Logged In
  useEffect(() => {
    if (!isLoading && !userData) {
      navigate("/login");
    }
  }, [isLoading, userData, navigate]);

  // Timer Logic
  useEffect(() => {
    if (gameState === "playing" && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && gameState === "playing") {
      setGameState("over");
    }

    return () => clearInterval(timerRef.current);
  }, [gameState, timeLeft]);

  // Stop Timer and Handle Game End
  const stopTimer = (reason) => {
    if (isGameStopped.current) return;
    isGameStopped.current = true;

    clearInterval(timerRef.current);

    if (reason === "gameWon" && !statsUpdatedRef.current) {
      console.log("Game won, updating BestTime...");
      statsUpdatedRef.current = true; // Prevent multiple updates
      updateBestTime(timeLeft, true); // Update BestTime
      setGameState("won");
    } else if (reason === "gameOver") {
      console.log("Game over, timer stopped.");
      setGameState("over");
    }

    setTimeLeft(0);
  };

  if (!banana) return <h2>Loading game...</h2>;

  return (
    <div>
      {gameState === "playing" && (
        <Game
          banana={banana}
          timeLeft={timeLeft}
          howManyHearts={howManyHearts}
          setHowManyHearts={setHowManyHearts}
          stopTimer={stopTimer}
          setGameState={setGameState}
          showIncorrectPopup={showIncorrectPopup}
          setShowIncorrectPopup={setShowIncorrectPopup}
          navigate={navigate}
        />
      )}
      {gameState === "over" && <GameOver />}
      {gameState === "won" && <GameWon timeLeft={timeLeft} />}
    </div>
  );
}

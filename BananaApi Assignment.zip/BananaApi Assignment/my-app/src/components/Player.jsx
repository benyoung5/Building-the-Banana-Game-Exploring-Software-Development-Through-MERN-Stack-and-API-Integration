// Player Component - Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to utilize UserContext, add dynamic heart display, and improve user feedback based on user data availability

// src/components/Player.jsx
import React from 'react';
import { useUser } from '../context/UserContext'; // Import the UserContext
import './style.css';

export default function Player({ HowManyHearts }) {
    // Access user data and loading state from the UserContext
    const { userData, isLoading } = useUser();

    // Show a loading state while user data is being retrieved
    if (isLoading) {
        return (
            <div className="container-fluids">
                <a className="btn btn-danger btn-lg m-3">
                    <p className="fw-bold">Loading...</p>
                    <p className="fw-bold">
                        {HowManyHearts >= 1 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                        {HowManyHearts >= 2 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                        {HowManyHearts >= 3 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                        {HowManyHearts >= 4 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                    </p>
                </a>
            </div>
        );
    }

    // If user data is not available or missing the name, show a fallback
    if (!userData || !userData.Name) {
        return (
            <div className="container-fluids">
                <a className="btn btn-danger btn-lg m-3">
                    <p className="fw-bold">Player not found</p>
                    <p className="fw-bold">
                        {HowManyHearts >= 1 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                        {HowManyHearts >= 2 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                        {HowManyHearts >= 3 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                        {HowManyHearts >= 4 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                    </p>
                </a>
            </div>
        );
    }

    // Render the player information when user data is available
    return (
        <div className="container-fluids">
            <a className="btn btn-danger btn-lg m-3">
                {/* Display the user's name */}
                <p className="fw-bold"><i className="bi bi-person-fill"></i> {userData.Name}</p>
                <p className="fw-bold">
                    {/* Display hearts based on HowManyHearts */}
                    {HowManyHearts >= 1 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                    {HowManyHearts >= 2 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                    {HowManyHearts >= 3 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                    {HowManyHearts >= 4 ? <i className="bi bi-suit-heart-fill text-danger mx-1"></i> : <i className="bi bi-suit-heart mx-1"></i>}
                </p>
            </a>
        </div>
    );
}

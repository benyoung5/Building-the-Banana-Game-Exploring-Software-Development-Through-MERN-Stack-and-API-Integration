// class LevelSingleton {
//     constructor() {
//       if (!LevelSingleton.instance) {
//         this.currentLevel = null;
//         LevelSingleton.instance = this;
//       }
//       return LevelSingleton.instance;
//     }
  
//     setLevel(currentLevel) {
//       this.currentLevel = currentLevel;
//     }
  
//     getLevel() {
//       return this.currentLevel;
//     }
//   }
  
//   // Create and export a single instance of LevelSingleton
//   const currentLevelSingleton = new LevelSingleton();
//   Object.freeze(currentLevelSingleton);  // Prevent further modifications to the instance
  
//   export default currentLevelSingleton;
  
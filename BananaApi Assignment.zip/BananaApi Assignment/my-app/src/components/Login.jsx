// Login Component - Adapted from "How To Make A Website With Login And Register | HTML CSS & Javascript" (2023)
// Modified to integrate with custom backend API and state management for the Banana Game project

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './style.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import CurrentUserNameSingleton from './UserSingleton'; 
import { setUserDataInStorage } from '../utils/storageUtils'; 
import { useUser } from '../context/UserContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const { updateUser } = useUser();

  // Handle login form submission
  const handleLogin = async (e) => {
    e.preventDefault();
    console.log('Login: Form submitted with email:', email);

    try {
      // Make login API request
      const response = await axios.post('http://localhost:3000/auth/login', {
        Email: email,
        Password: password,
      });

      console.log('Login: API response:', response.data);

      // Extract token and user data from response
      const { token, user } = response.data;

      // Map _id to id for consistency, if necessary
      if (user._id && !user.id) {
        user.id = user._id;
        delete user._id;
      }

      console.log('Login: User data after mapping _id to id:', user);

      // Add token to user data
      user.token = token;

      // Store token and user data in localStorage
      setUserDataInStorage(user); 
      localStorage.setItem('token', token);
      console.log('Login: Token saved to localStorage:', token);

      // Set user data in singleton
      CurrentUserNameSingleton.setUserName(user);
      console.log('Login: User data set in singleton:', CurrentUserNameSingleton.getUserName());

      // Update user context
      updateUser(user);
      console.log('Login: User data set in context:', user);

      // Navigate to home page upon successful login
      navigate('/home');
    } catch (err) {
      console.error('Login: Error during login:', err.response || err);
      setError(err.response?.data?.error || 'Login failed. Please check your credentials and try again.');
    }
  };

  return (
    <div className="wrapper login-wrapper">
      {/* Close button to navigate to the register page */}
      <span className="icon-close" onClick={() => navigate('/register')}>
        <i className="bi bi-x"></i> {/* X icon (Bootstrap icon) */}
      </span>

      <div className="form-box login">
        <h2>Login</h2>

        {/* Display error message if there is one */}
        {error && <p className="error-message">{error}</p>}

        <form onSubmit={handleLogin}>
          <div className="input-box">
            <span className="icon"><i className="bi bi-envelope"></i></span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <label>Email</label>
          </div>
          <div className="input-box">
            <span className="icon"><i className="bi bi-lock"></i></span>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <label>Password</label>
          </div>
          <div className="remember-forgot">
            <label><input type="checkbox" /> Remember me</label>
            <a href="#" id="forget_pass">Forgot password?</a>
          </div>
          <button type="submit" className="btn">Login</button>
          <div className="login-register">
            <p>Don't have an account?{' '}
              <a
                onClick={(e) => {
                  e.preventDefault();
                  navigate('/register');
                }}
                id="login-link"
                style={{ cursor: 'pointer' }}

              >
                Register
              </a>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;

// BestTime.js

export default async function updateBestTime(timeLeft, isGameWon) {
  if (!isGameWon) {
    console.log("Game not won; BestTime will not be recorded.");
    return;
  }

  let userData = JSON.parse(localStorage.getItem("userData"));
  const token = localStorage.getItem("token");

  console.log("Retrieved userData:", userData);
  console.log("Retrieved token:", token);

  if (!userData || !userData.id) {
    console.error("No valid user data found in localStorage.");
    return;
  }

  if (!token) {
    console.error("No valid token found in localStorage. User might need to log in.");
    return;
  }

  // Ensure the BestTime property is set before proceeding
  if (userData.BestTime == null || isNaN(userData.BestTime)) {
    userData.BestTime = 0; // Default to 0 for better comparisons
  }

  // Check if the BestTime has already been updated in the current session
  if (userData.hasUpdatedBestTime) {
    console.log("BestTime has already been updated for this game. Skipping redundant update.");
    return;
  }

  // Compare and update BestTime only if the new timeLeft is greater
  if (timeLeft > userData.BestTime) {
    userData.BestTime = timeLeft;

    try {
      // Log the token and endpoint details
      console.log("Updating BestTime with token:", token);
      console.log("Sending PUT request to:", `http://localhost:3000/Server/BestTime/${userData.id}`);

      // Send a PUT request to update BestTime on the server
      const response = await fetch(`http://localhost:3000/Server/BestTime/${userData.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ BestTime: timeLeft }),
      });

      if (!response.ok) {
        throw new Error("Failed to update BestTime on the server.");
      }

      // Handle a successful server response
      const serverResponse = await response.json();
      console.log("Server responded with updated data:", serverResponse);

      // Update localStorage with the new BestTime
      userData.hasUpdatedBestTime = true; // Mark BestTime as updated for the current session
      localStorage.setItem("userData", JSON.stringify(userData));
      alert(`New Best Time = ${timeLeft} seconds`);
    } catch (error) {
      console.error("Error updating BestTime on the server:", error);
    }
  } else {
    console.log("No update needed; current BestTime is better or equal.");
  }
}


import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import banana from '../Images/banana.png';
import { Link } from 'react-router-dom';

export default function Header() {
    return (
        <div className="container-fluid">
            <nav
                className="navbar navbar-expand-md navbar-dark fixed-top"
                style={{ cursor: 'default', 
                    background: 'rgba(10, 0, 0, 0.1)', 
                    justifyContent: 'center', 
                    alignItems: 'center',

                 }}
            >
        <Link
            to="/home" // Specify the path to HomeLinks
            className="navbar-brand fs-2 fw-bold font-arial"
            id="PageNameA"
        >
            &nbsp;&nbsp;&nbsp;
            <img
                src={banana}
                id="AaroophanIMG"
                height="50px"
                width="50px"
                className="rounded-5"
                alt="Logo"
            />{' '}
            Banana Game
        </Link>
            </nav>
        </div>
    );
}

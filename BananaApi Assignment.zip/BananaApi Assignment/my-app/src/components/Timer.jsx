// Timer Component - Adapted from Domeytoe - Comparative Integrated Systems Assignment - University of Bedfordshire (2023)
// Modified to provide a simplified timer display and use props for timeLeft in a functional component format

import React from 'react';

const Timer = ({ timeLeft }) => {
  return (
    <div style={{ fontSize: '1.2em'}}>
      <p>Timer: {timeLeft}s</p>
    </div>
  );
};

export default Timer;

class DailyChallengesSingleton {
    constructor() {
      if (!DailyChallengesSingleton.instance) {
        this.currentDailyChallenges = null;
        DailyChallengesSingleton.instance = this;
      }
      return DailyChallengesSingleton.instance;
    }
  
    setDailyChallenges(currentDailyChallenges) {
      this.currentDailyChallenges = currentDailyChallenges;
    }
  
    getDailyChallenges() {
      return this.currentDailyChallenges;
    }
  }
  
  // Create and export a single instance of DailyChallengesSingleton
  const currentDailyChallengesSingleton = new DailyChallengesSingleton();
  Object.freeze(currentDailyChallengesSingleton);  // Prevent modifications to the instance
  
  export default currentDailyChallengesSingleton;
  
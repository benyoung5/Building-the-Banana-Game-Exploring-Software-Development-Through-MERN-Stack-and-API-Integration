// Register Component - Adapted from "How To Make A Website With Login And Register | HTML CSS & Javascript" (2023)
// Modified to integrate with custom backend API and state management for the Banana Game project


import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './style.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const Register = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null); 
  const [success, setSuccess] = useState(false); 
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    // Reset success and error messages on each submit
    setSuccess(false);
    setError(null);

    try {
      const response = await axios.post('http://localhost:3000/auth/register', {
        UserID: Math.floor(Math.random() * 100000),
        Name: username.trim(),
        Email: email.trim().toLowerCase(),
        Password: password,
        DailyStreaks: 0,
        Rank: 0,
        BestTime: null,
        GamesPlayed: 0,
        GamesWon: 0,
        ChallengeDate: new Date().toISOString(),
      });

      // Display success message
      setSuccess(true);
      setError(null);

      // Redirect to login page after 2 seconds
      setTimeout(() => navigate('/login'), 2000);
    } catch (err) {
      // Handle errors returned by Axios
      setError(err.response?.data?.error || 'Registration failed');
    }
  };

  return (
    <div className="register-wrapper">
      {/* Close icon to go back to login page */}
      <span className="icon-close" onClick={() => navigate('/login')}>
        <i className="bi bi-x"></i>
      </span>

      <div className="form-box register">
        <h2>Registration</h2>

        {/* Success and Error Messages */}
        {success && <p className="success-message">Registration successful! Redirecting...</p>}
        {error && <p className="error-message">{error}</p>}

        <form onSubmit={handleRegister}>
          <div className="input-box">
            <span className="icon"><i className="bi bi-person"></i></span>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <label>Username</label>
          </div>
          
          <div className="input-box">
            <span className="icon"><i className="bi bi-envelope"></i></span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <label>Email</label>
          </div>
          
          <div className="input-box">
            <span className="icon"><i className="bi bi-lock"></i></span>
            <input
              type="password"
              required
              minLength="6" // Ensures password has at least 6 characters
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <label>Password</label>
          </div>
          
          <div className="remember-forgot">
            <label className="checkbox_text">
              <input type="checkbox" required /> I agree to the terms & conditions
            </label>
          </div>

          <button type="submit" className="btn">Register</button>

          <div className="login-register">
            <p>Already have an account? 
              <a href="#" onClick={(e) => { e.preventDefault(); navigate('/login'); }} id="login-link"> Login</a>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
